import React from 'react'

const App = () => {
  return (
    <div className='text-6xl text-red-900'>App</div>
  )
}

export default App